# Validação de integrações

Estado inicial: aplicativo ainda não implementado; nenhuma integração testada ao vivo.

| Integração | Implementação | Contrato/fixture | Ao vivo | Pendência |
|---|---|---|---|---|
| LLM | pendente | pendente | não testado | M02/M03 |
| Gemini Image | pendente | pendente | não testado | M02/M05 |
| OpenAI Image | pendente | pendente | não testado | M02/M05 |
| Firefly Image | pendente | pendente | não testado | M02/M05 |
| Custom Image | pendente | pendente | não testado | M02 |
| Instagram/Analytics | pendente | pendente | não testado | M09/M10 |

O agente atualiza esta matriz com documentação oficial/data, modelos confirmados, limitações, cenários executados e autorização quando houver validação real. Não registrar credenciais. Diferenciar adaptador implementado, contrato simulado e teste ao vivo bem-sucedido.
